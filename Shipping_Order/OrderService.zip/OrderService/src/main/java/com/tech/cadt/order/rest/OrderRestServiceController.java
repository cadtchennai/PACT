package com.tech.cadt.order.rest;



import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import org.springframework.web.bind.annotation.RestController;
import com.tech.cadt.order.entity.OrderProduct;

@RestController
@RequestMapping("/orders")
@Component
public class OrderRestServiceController {  

   @RequestMapping(value="/create", method = RequestMethod.POST,consumes="application/json;charset=UTF-8",
			produces="application/json;charset=UTF-8")
	
	public OrderProduct getDetails(@RequestBody int orderId,HttpServletResponse httpServletResponse,
			@RequestHeader HttpHeaders headers,HttpServletRequest httpServletRequest) throws Exception{
		OrderProduct orders=new OrderProduct();
		if(orderId==1)
		{
			orders.setUsername("mani");
			orders.setDeliveryAddr("chennai");
		}
		return orders;
	}	
   @RequestMapping(value="/getAll", method = RequestMethod.GET,
			produces="application/json;charset=UTF-8")
   public OrderProduct getAllDetails(HttpServletResponse httpServletResponse,
			@RequestHeader HttpHeaders headers,HttpServletRequest httpServletRequest) throws Exception{
		OrderProduct orders=new OrderProduct();
		
			orders.setUsername("mani");
			orders.setDeliveryAddr("chennai");
			orders.setOrderQuantity(5);
			orders.setTotalAmt(1000);
			orders.setOrderId(50);
		
		return orders;
	}	
	}