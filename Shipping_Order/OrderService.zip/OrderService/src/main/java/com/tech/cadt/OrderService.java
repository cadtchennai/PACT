package com.tech.cadt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;



@EnableWebMvc
@SpringBootApplication
@Component
@ComponentScan("com.tech.cadt.*")
public class OrderService {
	public static void main(String[] args) {
		SpringApplication.run(OrderService.class, args);
	}
}